r"""
Graph convolution network
"""
from .combnet import CombUnweighted