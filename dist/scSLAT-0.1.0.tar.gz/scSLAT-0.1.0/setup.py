# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['scSLAT',
 'scSLAT.model',
 'scSLAT.model.graphconv',
 'scSLAT.model.prematch',
 'scSLAT.viz']

package_data = \
{'': ['*']}

install_requires = \
['anndata>0.7',
 'dill>0.2.3',
 'faiss-cpu',
 'h5py',
 'harmony-pytorch',
 'harmonypy',
 'joblib',
 'leidenalg',
 'matplotlib>3.1.2',
 'numpy>1.19',
 'opencv-python',
 'packaging',
 'pandas>1.1',
 'parse>1.3.2',
 'plotly',
 'pynvml',
 'pyyaml',
 'scanpy>1.5',
 'scikit-learn>0.21.2',
 'scikit-misc',
 'scipy>1.3',
 'seaborn>0.9',
 'statsmodels>0.10',
 'tqdm>4.27']

extras_require = \
{'cpu': ['torch @ '
         'https://download.pytorch.org/whl/cpu/torch-1.11.0%2Bcpu-cp38-cp38-linux_x86_64.whl',
         'torch-scatter @ '
         'https://data.pyg.org/whl/torch-1.11.0%2Bcpu/torch_scatter-2.0.9-cp38-cp38-linux_x86_64.whl',
         'torch-sparse @ '
         'https://data.pyg.org/whl/torch-1.11.0%2Bcpu/torch_sparse-0.6.13-cp38-cp38-linux_x86_64.whl',
         'torch-cluster @ '
         'https://data.pyg.org/whl/torch-1.11.0%2Bcpu/torch_cluster-1.6.0-cp38-cp38-linux_x86_64.whl',
         'torch-geometric'],
 'dev': ['pytest',
         'pytest-cov',
         'papermill',
         'snakemake',
         'ipykernel',
         'ipython',
         'jupyter'],
 'docs': ['sphinx',
          'sphinx-autodoc-typehints',
          'sphinx-copybutton',
          'sphinx-intl',
          'nbsphinx',
          'sphinx-rtd-theme',
          'sphinx_gallery>=0.8.2,<0.11',
          'jinja2',
          'myst-parser',
          'pandoc',
          'ipykernel']}

setup_kwargs = {
    'name': 'scslat',
    'version': '0.1.0',
    'description': 'A graph deep learning based tool to align single cell spatial omics data',
    'long_description': '[![stars-badge](https://img.shields.io/github/stars/gao-lab/SLAT?logo=GitHub&color=yellow)](https://github.com/gao-lab/SLAT/stargazers)\n[![dev-badge](https://img.shields.io/endpoint?url=https://gist.githubusercontent.com/xiachenrui/bc835db052fde5bd731a09270b42006c/raw/version.json)](https://gist.github.com/xiachenrui/bc835db052fde5bd731a09270b42006c)\n[![build-badge](https://github.com/gao-lab/SLAT/actions/workflows/build.yml/badge.svg)](https://github.com/gao-lab/SLAT/actions/workflows/build.yml)\n[![license-badge](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)\n<!-- [![pypi-badge](https://img.shields.io/pypi/v/<name>)](https://pypi.org/project/<name>) -->\n<!-- [![conda-badge](https://anaconda.org/bioconda/<name>/badges/version.svg)](https://anaconda.org/bioconda/<name>) -->\n<!-- [![docs-badge](https://readthedocs.org/projects/<name>/badge/?version=latest)](https://<name>.readthedocs.io/en/latest/?badge=latest) -->\n\n# scSLAT: single cell spatial alignment tools\n\n**scSLAT** package implements the **SLAT** (**S**patial **L**inked **A**lignment **T**ool) model to align single cell spatial omics data.\n\n![Model architecture](docs/_static/Model.png)\n\n## Directory structure\n\n```\n.\n├── scSLAT/                  # Main Python package\n├── env/                     # Extra environment\n├── data/                    # Data files\n├── evaluation/              # SLAT evaluation pipeline\n├── benchmark/               # Benchmark pipeline\n├── case/                    # Case studies in paper\n├── docs/                    # Documentation files\n├── resource/                # Other useful resource \n├── pyproject.toml           # Python package metadata\n└── README.md\n```\n\n## Tutorial\nTutorial of `scSLAT` is [here](TBD), if you have any question please open an issue on github\n\n## Installation\n### Install from PyPI\n> Installing `scSLAT` within a new [conda environment](https://conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html) is recommended.\n\nFist we create a clean environment and activate it:\n```bash\nconda create -n scSLAT python=3.8 -y && conda activate scSLAT\n```\nThen we install `scSLAT` from PyPI.\nIf you have a CUDA-enabled GPU, we strong recommend you install SLAT with GPU support, it will 5x faster than CPU. You should install [PyG](https://pytorch-geometric.readthedocs.io/en/latest/index.html) first because it can not correctly install from PyPI.\n\n```bash\nconda install pytorch=1.11.0 torchvision torchaudio cudatoolkit=11.3 -c pytorch -y\nconda install pyg -c pyg -y\npip install scSLAT\n```\nHowever, if you only want to run on CPU, you can directly install CPU version:\n```bash\npip install scSLAT[cpu]\n```\n### Docker container\nDockerfile of `scSLAT` is available at [`env/Dockerfile`](env/Dockerfile)\n\n### Install from Conda (Ongoing)\nWe plan to provide a conda package of `scSLAT` in the near future.\n\n### Development\nFor development purpose, clone this repo and run:\n```bash\npip install -e ".[dev]"\n```\n\n## Reproduce results\n1. Please follow the [`env/README.md`](env/README.md) to install all dependencies. Please checkout the repository to v0.1.0 before install `scSLAT`:\n\n```\ngit checkout tags/v0.1.0\npip install -e \'.\'\n```\n\n2. Download files via links in [`data/README.md`](data/README.md)\n\n2. Whole benchmark and evaluation procedure can be found in `/benchmark` and `/evaluation`, respectively.\n\n3. Every case study is recorded in the `/case` directory in the form of jupyter notebook.\n\n',
    'author': 'Chen-Rui Xia',
    'author_email': 'xiachenrui@mail.cbi.pku.edu.cn',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/gao-lab/SLAT',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
